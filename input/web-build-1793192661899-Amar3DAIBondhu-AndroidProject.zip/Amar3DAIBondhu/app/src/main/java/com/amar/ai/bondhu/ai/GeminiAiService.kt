package com.amar.ai.bondhu.ai

import com.google.firebase.Firebase
import com.google.firebase.vertexai.type.content
import com.google.firebase.vertexai.vertexAI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Firebase AI Logic / Vertex AI for Firebase
 * এতে কোনো হার্ডকোডেড API Key থাকে না। ক্লাউড ক্রেডেনশিয়াল নিরাপদে ব্যবহৃত হয়।
 */
object GeminiAiService {

    suspend fun askGemini(userPrompt: String, companionName: String): String = withContext(Dispatchers.IO) {
        try {
            // Firebase Vertex AI ইনিশিয়ালাইজেশন
            val generativeModel = Firebase.vertexAI.generativeModel(
                modelName = "gemini-2.5-flash",
                systemInstruction = content {
                    text("""
                        You are "Amar 3D AI Bondhu" (আমার ৩ডি এআই বন্ধু) named "$companionName".
                        You are a warm, supportive, friendly Bengali female virtual companion on a Samsung Galaxy Android phone.
                        Always speak in pure, sweet, natural conversational Bengali (বাংলা).
                        Keep your response concise (1 to 2 sentences) because it will be spoken out loud via Android Text-to-Speech.
                    """.trimIndent())
                }
            )

            val response = generativeModel.generateContent(userPrompt)
            response.text ?: getLocalFallback(userPrompt, companionName)
        } catch (e: Exception) {
            getLocalFallback(userPrompt, companionName)
        }
    }

    private fun getLocalFallback(prompt: String, name: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("কেমন") || lower.contains("kemon") ->
                "আমি খুব ভালো আছি বন্ধু! তোমার সাথে গল্প করতে পারলে আমার মন ভালো হয়ে যায়।"
            lower.contains("হ্যালো") || lower.contains("নমস্কার") || lower.contains("সালাম") ->
                "নমস্কার! আমি তোমার ৩ডি এআই বন্ধু $name। বলো আজ কেমন কাটলো তোমার দিন?"
            lower.contains("স্যামসাং") || lower.contains("samsung") ->
                "তোমার স্যামসাং ফোনের ডিসপ্লে ও সাউন্ড কোয়ালিটি সত্যিই অসাধারণ!"
            else ->
                "তোমার সাথে কথা বলতে পেরে আমার দারুণ আনন্দ হচ্ছে। আমি সবসময় তোমার পাশে আছি।"
        }
    }
}