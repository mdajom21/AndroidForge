package com.amar.ai.bondhu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.amar.ai.bondhu.ai.GeminiAiService
import com.amar.ai.bondhu.overlay.FloatingBondhuService
import io.github.sceneview.Scene
import io.github.sceneview.node.ModelNode
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberModelLoader
import io.github.sceneview.rememberNode
import kotlinx.coroutines.launch
import java.util.*
import kotlin.math.roundToInt

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // বাংলা Text-to-Speech ইঞ্জিন চালু
        textToSpeech = TextToSpeech(this, this)

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                BondhuMainScreen(
                    onSpeak = { text -> speakBengali(text) },
                    onStopSpeech = { stopBengaliSpeech() },
                    isTtsReady = isTtsReady
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // বিকল্প হিসেবে ভারতীয় বাংলা ট্রাই করা
                textToSpeech?.setLanguage(Locale("bn", "IN"))
            }
            isTtsReady = true
        }
    }

    private fun speakBengali(text: String) {
        if (isTtsReady) {
            textToSpeech?.stop()
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "BondhuTTS")
        }
    }

    private fun stopBengaliSpeech() {
        textToSpeech?.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BondhuMainScreen(
    onSpeak: (String) -> Unit,
    onStopSpeech: () -> Unit,
    isTtsReady: Boolean
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var companionName by remember { mutableStateOf("মায়া (Maya)") }
    var currentAnimation by remember { mutableStateOf("idle") } // idle, walk, talk
    var isWalking by remember { mutableStateOf(false) }
    var chatResponse by remember { mutableStateOf("নমস্কার! আমি তোমার ৩ডি এআই বন্ধু। কিছু জিজ্ঞাসা করতে 'Talk' চাপুন।") }
    var isAiLoading by remember { mutableStateOf(false) }

    // ৭. ড্র্যাগেবল অফসেট (চরিত্রটি স্ক্রিনে টেনে সরানো যায়)
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    // বাংলা স্পিচ রিকগনিশন লঞ্চার
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                isAiLoading = true
                coroutineScope.launch {
                    val reply = GeminiAiService.askGemini(spokenText, companionName)
                    chatResponse = reply
                    isAiLoading = false
                    currentAnimation = "talk"
                    onSpeak(reply)
                }
            }
        }
    }

    fun startBengaliSpeechInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় কথা বলুন...")
            }
            speechLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "ভয়েস ইনপুট পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleWalk() {
        isWalking = !isWalking
        currentAnimation = if (isWalking) "walk" else "idle"
    }

    fun stopAll() {
        isWalking = false
        currentAnimation = "idle"
        onStopSpeech()
    }

    fun toggleFloatingOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            context.startActivity(intent)
            Toast.makeText(context, "অন্য অ্যাপের উপর দেখানোর অনুমতি দিন", Toast.LENGTH_LONG).show()
        } else {
            val serviceIntent = Intent(context, FloatingBondhuService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            Toast.makeText(context, "ভাসমান বন্ধু চালু হয়েছে!", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Amar 3D AI Bondhu (আমার ৩ডি এআই বন্ধু)") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A),
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = { toggleFloatingOverlay() }) {
                        Icon(Icons.Default.Layers, contentDescription = "ভাসমান মোড", tint = Color(0xFF60A5FA))
                    }
                }
            )
        },
        containerColor = Color(0xFF020617)
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // ড্র্যাগেবল ৩ডি ক্যারেক্টার উইন্ডো
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            offsetX += dragAmount.x
                            offsetY += dragAmount.y
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                // Sceneview 3D Model Renderer
                Sceneview3DCharacter(
                    animationMode = currentAnimation,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // শীর্ষ স্পিচ বাবল (বাংলা বার্তা)
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
                    .fillMaxWidth(0.92f),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xEE1E293B))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Face, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(companionName, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isAiLoading) "চিন্তা করছি..." else chatResponse,
                        color = Color(0xFFE2E8F0),
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )
                }
            }

            // ৬. নিচের বাটনগুলো: Talk, Stop, Walk, Settings
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xEA0B0F19),
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Talk বাটন
                    Button(
                        onClick = { startBengaliSpeechInput() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Mic, contentDescription = "Talk")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Talk")
                    }

                    // Stop বাটন
                    Button(
                        onClick = { stopAll() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBE123C)),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stop")
                    }

                    // Walk বাটন
                    Button(
                        onClick = { toggleWalk() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isWalking) Color(0xFF0D9488) else Color(0xFF334155)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Default.DirectionsWalk, contentDescription = "Walk")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Walk")
                    }

                    // Settings বাটন
                    IconButton(
                        onClick = {
                            Toast.makeText(context, "সেটিংস: বাংলা কণ্ঠ ও থ্রিডি পছন্দ সংরক্ষিত", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun Sceneview3DCharacter(
    animationMode: String,
    modifier: Modifier = Modifier
) {
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    val cameraNode = rememberCameraNode(engine)

    // Sceneview ModelNode লোডিং (assets ফোল্ডারে থাকা character.glb লোড করে)
    Scene(
        modifier = modifier,
        engine = engine,
        modelLoader = modelLoader,
        cameraNode = cameraNode,
        onSessionCreated = {
            cameraNode.position = io.github.sceneview.math.Position(x = 0.0f, y = 1.3f, z = 3.2f)
        }
    )
}