# Sceneview and Filament rules
-keep class io.github.sceneview.** { *; }
-keep class com.google.android.filament.** { *; }